package com.fatec.fatura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FaturaBack1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
