package com.fatec.fatura;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FaturaBack1Application {

	public static void main(String[] args) {
		SpringApplication.run(FaturaBack1Application.class, args);
	}

}
